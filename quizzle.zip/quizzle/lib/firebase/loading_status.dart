enum LoadingStatus{
  loading, completed, error, noReult
}