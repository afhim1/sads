

import 'package:get/get.dart';

class AppInizialitingController extends GetxController {

  @override
  void onReady() {
    initApp();
    super.onReady();
  }
 
  void initApp() async {
    
  }
}
